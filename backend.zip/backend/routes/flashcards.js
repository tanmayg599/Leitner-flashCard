import express from "express";
import {
    getFlashcards,
    addFlashcard,
    updateFlashcard,
    deleteFlashcard,
} from "../controllers/flashcardController.js";

const router = express.Router();

router.post("/", addFlashcard);
router.get("/", getFlashcards);
router.put("/:id", updateFlashcard);
router.delete("/:id", deleteFlashcard);

export default router;
