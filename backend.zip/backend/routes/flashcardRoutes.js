import express from "express";
import Flashcard from "../models/Flashcard.js";
import { authenticateUser } from "./authRoutes.js";

const router = express.Router();

// Get all flashcards (Authenticated)
router.get("/", authenticateUser, async (req, res) => {
    try {
        const flashcards = await Flashcard.find({ user: req.user.id });
        res.json(flashcards);
    } catch (err) {
        res.status(500).json({ msg: "Server error" });
    }
});

// Add a new flashcard (Authenticated)
router.post("/", authenticateUser, async (req, res) => {
    try {
        const { question, answer } = req.body;
        const newFlashcard = new Flashcard({ question, answer, user: req.user.id });
        await newFlashcard.save();
        res.json(newFlashcard);
    } catch (err) {
        res.status(500).json({ msg: "Server error" });
    }
});

export default router;
