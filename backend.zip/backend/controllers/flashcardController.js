import Flashcard from "../models/Flashcard.js";

// Get all flashcards
export const getFlashcards = async (req, res) => {
    const flashcards = await Flashcard.find().sort({ nextReview: 1 });
    res.json(flashcards);
};

// Add a new flashcard
export const addFlashcard = async (req, res) => {
    const { question, answer } = req.body;
    const newFlashcard = new Flashcard({ question, answer });
    await newFlashcard.save();
    res.status(201).json(newFlashcard);
};

// Update flashcard (Leitner System logic)
export const updateFlashcard = async (req, res) => {
    const { id } = req.params;
    const { correct } = req.body;
    const flashcard = await Flashcard.findById(id);

    if (!flashcard) return res.status(404).json({ message: "Not Found" });

    if (correct) {
        flashcard.box = Math.min(5, flashcard.box + 1);
        flashcard.nextReview = new Date(Date.now() + flashcard.box * 24 * 60 * 60 * 1000);
    } else {
        flashcard.box = 1;
        flashcard.nextReview = new Date();
    }
    await flashcard.save();
    res.json(flashcard);
};

// Delete a flashcard
export const deleteFlashcard = async (req, res) => {
    await Flashcard.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
};
