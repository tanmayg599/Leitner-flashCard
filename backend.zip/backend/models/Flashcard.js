import mongoose from "mongoose";

const flashcardSchema = new mongoose.Schema({
    question: String,
    answer: String,
    box: { type: Number, default: 1 },
    nextReview: { type: Date, default: Date.now }
});

export default mongoose.model("Flashcard", flashcardSchema);
