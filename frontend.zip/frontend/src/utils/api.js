import axios from "axios";

const API_URL = "http://localhost:5000/flashcards";

export const getFlashcards = async () => {
    const res = await axios.get(API_URL);
    return res.data;
};

export const addFlashcard = async (flashcard) => {
    await axios.post(API_URL, flashcard);
};

export const reviewFlashcard = async (id, correct) => {
    await axios.put(`${API_URL}/${id}`, { correct });
};

export const deleteFlashcard = async (id) => {
    await axios.delete(`${API_URL}/${id}`);
};
