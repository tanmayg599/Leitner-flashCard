import React, { useEffect, useState } from "react";
import { getFlashcards, reviewFlashcard } from "../utils/api";

const Review = () => {
    const [flashcards, setFlashcards] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const fetchFlashcards = async () => {
            const data = await getFlashcards();
            setFlashcards(data);
        };
        fetchFlashcards();
    }, []);

    const handleReview = async (correct) => {
        await reviewFlashcard(flashcards[currentIndex]._id, correct);
        setCurrentIndex((prev) => (prev + 1) % flashcards.length);
    };

    if (!flashcards.length) return <p>Loading...</p>;

    return (
        <div className="container text-center p-5">
            <h2>Review Flashcards</h2>
            <div className="card p-3">
                <h4>{flashcards[currentIndex].question}</h4>
                <button className="btn btn-info" onClick={() => alert(flashcards[currentIndex].answer)}>Show Answer</button>
                <button className="btn btn-success m-2" onClick={() => handleReview(true)}>Correct</button>
                <button className="btn btn-danger m-2" onClick={() => handleReview(false)}>Incorrect</button>
            </div>
        </div>
    );
};

export default Review;
