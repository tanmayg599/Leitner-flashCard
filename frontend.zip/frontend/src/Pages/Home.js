import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
    return (
        <div className="container text-center p-5">
            <h1>Leitner Flashcard System</h1>
            <p>Efficiently learn and review flashcards using the Leitner system.</p>
            <Link to="/review" className="btn btn-primary">Start Reviewing</Link>
        </div>
    );
};

export default Home;
